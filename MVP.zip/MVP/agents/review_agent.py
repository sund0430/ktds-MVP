#리뷰 수집/분석 에이전트

from google_play_scraper import reviews

result, _ = reviews(
    'com.kakao.talk',  # 앱 ID (예: 카카오톡)
    lang='ko',         # 한국어
    country='kr',      # 한국 스토어
    count=10           # 가져올 리뷰 개수
)

for r in result:
    print(r["content"])
